<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title ?? __('site.title')); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('marketplace.css')); ?>">
</head>
<body class="locale-<?php echo e(app()->getLocale()); ?>">
    <div class="topbar">
        <div class="container nav">
            <a class="brand" href="<?php echo e(route('home')); ?>">
                <span class="brand-mark">GK</span>
                <span class="brand-text">
                    <strong><?php echo e(__('site.brand')); ?></strong>
                    <small><?php echo e(__('site.country')); ?></small>
                </span>
            </a>
            <div class="nav-links">
                <a href="<?php echo e(route('home')); ?>#top"><?php echo e(__('site.nav_home')); ?></a>
                <a href="<?php echo e(route('home')); ?>#services"><?php echo e(__('site.nav_services')); ?></a>
                <a href="<?php echo e(route('home')); ?>#providers">Providers</a>
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('site.nav_dashboard')); ?></a>
                <?php endif; ?>
            </div>
            <div class="nav-actions">
                <div class="locale-switcher" aria-label="<?php echo e(__('site.language')); ?>">
                    <?php $__currentLoopData = $supportedLocales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $localeLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="locale-link <?php echo e($currentLocale === $localeCode ? 'active' : ''); ?>" href="<?php echo e(request()->fullUrlWithQuery(['lang' => $localeCode])); ?>"><?php echo e($localeLabel); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php if(auth()->guard()->check()): ?>
                    <span class="badge"><?php echo e(auth()->user()->name); ?> - <?php echo e(auth()->user()->role); ?></span>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button class="btn secondary" type="submit"><?php echo e(__('site.logout')); ?></button>
                    </form>
                <?php else: ?>
                    <a class="btn secondary" href="<?php echo e(route('login')); ?>"><?php echo e(__('site.login')); ?></a>
                    <a class="btn brand" href="<?php echo e(route('register')); ?>"><?php echo e(__('site.create_account')); ?></a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <main id="top">
        <div class="container">
            <?php if(session('success')): ?>
                <div class="flash success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="flash error"><?php echo e($errors->first()); ?></div>
            <?php endif; ?>
        </div>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <footer class="footer">
        <div class="container footer-shell">
            <div>
                <strong><?php echo e(__('site.title')); ?></strong>
                <div><?php echo e(__('site.footer_text')); ?></div>
            </div>
            <div><?php echo e(__('site.footer_subtext')); ?></div>
        </div>
    </footer>
</body>
</html><?php /**PATH C:\xampp\htdocs\home_services_marketplace_laravel_prd\resources\views/layouts/app.blade.php ENDPATH**/ ?>