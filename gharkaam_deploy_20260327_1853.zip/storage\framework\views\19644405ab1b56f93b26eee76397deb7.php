<?php $__env->startSection('content'); ?>
<div class="page">
    <div class="container search-layout">
        <section class="hero-shell home-shell">
            <div class="hero-grid home-grid">
                <div class="home-copy">
                    <span class="kicker"><?php echo e(__('site.hero_kicker')); ?></span>
                    <h1><?php echo e(__('site.hero_title')); ?></h1>
                    <p><?php echo e(__('site.hero_text')); ?></p>
                    <div class="hero-actions">
                        <a class="btn brand" href="#services"><?php echo e(__('site.search_button')); ?></a>
                        <a class="btn secondary" href="#providers"><?php echo e(__('site.top_providers_title')); ?></a>
                    </div>
                    <div class="stats">
                        <div class="stat"><span>Live Services</span><strong><?php echo e($stats['services']); ?></strong></div>
                        <div class="stat"><span>Verified Providers</span><strong><?php echo e($stats['providers']); ?></strong></div>
                        <div class="stat"><span>Bookings</span><strong><?php echo e($stats['bookings']); ?></strong></div>
                        <div class="stat"><span>Reviews</span><strong><?php echo e($stats['reviews']); ?></strong></div>
                    </div>
                </div>
                <div class="search-shell home-search-shell">
                    <div class="search-panel">
                        <h3 style="margin-top:0;"><?php echo e(__('site.search_title')); ?></h3>
                        <form method="GET" action="<?php echo e(route('home')); ?>#services">
                            <datalist id="location-suggestions-home">
                                <?php $__currentLoopData = $locationSuggestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $suggestion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($suggestion); ?>"></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </datalist>
                            <div class="hero-search-grid">
                                <label style="margin-bottom:0;"><?php echo e(__('site.search_need')); ?>

                                    <input type="text" name="search" value="<?php echo e($filters['search'] ?? ''); ?>" placeholder="<?php echo e(__('site.search_need_placeholder')); ?>">
                                </label>
                                <label style="margin-bottom:0;"><?php echo e(__('site.search_location')); ?>

                                    <div class="location-input">
                                        <input type="text" name="location" value="<?php echo e($filters['location'] ?? ''); ?>" list="location-suggestions-home" placeholder="<?php echo e(__('site.search_location_placeholder')); ?>">
                                        <?php if(auth()->guard()->check()): ?>
                                            <button class="btn secondary location-trigger" type="button" data-target="input[name=&quot;location&quot;]" data-location="<?php echo e(auth()->user()->city); ?>"><?php echo e(__('site.search_saved_city')); ?></button>
                                        <?php endif; ?>
                                    </div>
                                </label>
                                <label style="margin-bottom:0;"><?php echo e(__('site.search_category')); ?>

                                    <select name="category">
                                        <option value=""><?php echo e(__('site.search_all_categories')); ?></option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->slug); ?>" <?php if(($filters['category'] ?? '') === $category->slug): echo 'selected'; endif; ?>><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </label>
                                <div style="display:flex;align-items:end;">
                                    <button class="btn brand" type="submit" style="width:100%;"><?php echo e(__('site.search_button')); ?></button>
                                </div>
                            </div>
                        </form>
                        <div class="hero-search-note">
                            <span><?php echo e(__('site.search_fast_booking')); ?></span>
                            <span><?php echo e(__('site.search_provider_dashboard')); ?></span>
                            <span><?php echo e(__('site.search_ratings')); ?></span>
                            <span><?php echo e(__('site.search_location_feature')); ?></span>
                        </div>
                    </div>
                    <div class="card">
                        <div class="location-row">
                            <strong><?php echo e(__('site.current_location')); ?></strong>
                            <button class="btn secondary current-location-button" type="button" data-target="input[name=&quot;location&quot;]"><?php echo e(__('site.detect_now')); ?></button>
                        </div>
                        <p class="muted current-location-text" style="margin:10px 0 0;">
                            <?php if(auth()->guard()->check()): ?>
                                <?php echo e(__('site.saved_city')); ?>: <?php echo e(auth()->user()->city); ?>

                            <?php else: ?>
                                <?php echo e(__('site.allow_location')); ?>

                            <?php endif; ?>
                        </p>
                    </div>
                </div>
            </div>
        </section>

        <section class="section" id="categories">
            <div class="section-head">
                <div>
                    <h2><?php echo e(__('site.home_categories_title')); ?></h2>
                    <p><?php echo e(__('site.home_categories_text')); ?></p>
                </div>
            </div>
            <div class="grid grid-4">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="card icon-card" href="<?php echo e(route('home', ['category' => $category->slug])); ?>#services">
                        <span class="badge"><?php echo e($category->services_count); ?> <?php echo e(__('site.services_count')); ?></span>
                        <h3><?php echo e($category->name); ?></h3>
                        <p><?php echo e($category->description); ?></p>
                        <span class="btn secondary"><?php echo e(__('site.explore_category')); ?></span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>

        <section class="section" id="services">
            <div class="section-head">
                <div>
                    <h2><?php echo e(__('site.featured_services_title')); ?></h2>
                    <p><?php echo e(__('site.featured_services_text')); ?></p>
                </div>
                <?php if(($filters['search'] ?? null) || ($filters['location'] ?? null) || ($filters['category'] ?? null)): ?>
                    <a class="btn secondary" href="<?php echo e(route('home')); ?>#services">Clear filters</a>
                <?php endif; ?>
            </div>
            <div class="grid grid-3">
                <?php $__empty_1 = true; $__currentLoopData = $featuredServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="card service-card">
                        <?php if($service->image_path): ?>
                            <img class="service-thumb" src="<?php echo e(asset($service->image_path)); ?>" alt="<?php echo e($service->title); ?>">
                        <?php else: ?>
                            <div class="service-thumb"></div>
                        <?php endif; ?>
                        <div class="service-card-body">
                            <span class="badge"><?php echo e($service->category->name); ?></span>
                            <h3><?php echo e($service->title); ?></h3>
                            <p><?php echo e($service->short_description); ?></p>
                            <div class="notice"><?php echo e($service->provider->service_area); ?> - <?php echo e($service->provider->user->city); ?></div>
                            <div class="provider-strip">
                                <span class="avatar-pill"><?php echo e($service->provider->user->name); ?></span>
                                <span class="price">PKR <?php echo e(number_format($service->price)); ?></span>
                            </div>
                            <div class="stack-actions" style="margin-top:16px;">
                                <?php if(auth()->check() && auth()->user()->isCustomer()): ?>
                                    <a class="btn brand" href="<?php echo e(route('bookings.create', $service->slug)); ?>">Book now</a>
                                <?php else: ?>
                                    <a class="btn brand" href="<?php echo e(route('login')); ?>">Login to book</a>
                                <?php endif; ?>
                                <a class="btn secondary" href="tel:<?php echo e(preg_replace('/\D+/', '', $service->provider->user->phone)); ?>">Call</a>
                                <a class="btn secondary" href="https://wa.me/<?php echo e(preg_replace('/\D+/', '', $service->provider->user->phone)); ?>" target="_blank" rel="noopener">WhatsApp</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="card">
                        <h3>No services found</h3>
                        <p>Search, category, ya location change karke dobara try karein.</p>
                    </div>
                <?php endif; ?>
            </div>
        </section>

        <section class="section" id="providers">
            <div class="section-head">
                <div>
                    <h2><?php echo e(__('site.top_providers_title')); ?></h2>
                    <p><?php echo e(__('site.top_providers_text')); ?></p>
                </div>
            </div>
            <div class="grid grid-3">
                <?php $__empty_1 = true; $__currentLoopData = $featuredProviders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="card">
                        <span class="badge"><?php echo e($provider->service_area); ?></span>
                        <h3><?php echo e($provider->user->name); ?></h3>
                        <p><?php echo e($provider->bio); ?></p>
                        <div class="notice"><?php echo e($provider->user->city); ?> - <?php echo e($provider->experience_years); ?> <?php echo e(__('site.years_experience')); ?> - PKR <?php echo e(number_format($provider->hourly_rate)); ?>/hr</div>
                        <div class="stack-actions" style="margin-top:16px;">
                            <a class="btn secondary" href="tel:<?php echo e(preg_replace('/\D+/', '', $provider->user->phone)); ?>">Call</a>
                            <a class="btn brand" href="https://wa.me/<?php echo e(preg_replace('/\D+/', '', $provider->user->phone)); ?>" target="_blank" rel="noopener">WhatsApp</a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="card">
                        <h3>No providers found</h3>
                        <p>Location ya category filters change karke dobara try karein.</p>
                    </div>
                <?php endif; ?>
            </div>
        </section>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.location-trigger').forEach(function (button) {
        button.addEventListener('click', function () {
            var target = document.querySelector(button.dataset.target);
            if (!target || !button.dataset.location) {
                return;
            }

            target.value = button.dataset.location;
            button.textContent = <?php echo json_encode(__('site.city_added'), 15, 512) ?>;
        });
    });

    document.querySelectorAll('.current-location-button').forEach(function (button) {
        button.addEventListener('click', function () {
            var target = document.querySelector(button.dataset.target);
            var info = document.querySelector('.current-location-text');
            if (!navigator.geolocation || !target || !info) {
                return;
            }

            button.disabled = true;
            button.textContent = <?php echo json_encode(__('site.detecting'), 15, 512) ?>;
            info.textContent = <?php echo json_encode(__('site.detecting'), 15, 512) ?>;

            navigator.geolocation.getCurrentPosition(function (position) {
                var coords = position.coords.latitude.toFixed(5) + ', ' + position.coords.longitude.toFixed(5);
                target.value = coords;
                info.textContent = <?php echo json_encode(__('site.current_location_label'), 15, 512) ?> + ': ' + coords;
                button.textContent = <?php echo json_encode(__('site.location_ready'), 15, 512) ?>;
            }, function () {
                info.textContent = <?php echo json_encode(__('site.allow_location'), 15, 512) ?>;
                button.disabled = false;
                button.textContent = <?php echo json_encode(__('site.detect_now'), 15, 512) ?>;
            });
        });
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\home_services_marketplace_laravel_prd\resources\views/home.blade.php ENDPATH**/ ?>